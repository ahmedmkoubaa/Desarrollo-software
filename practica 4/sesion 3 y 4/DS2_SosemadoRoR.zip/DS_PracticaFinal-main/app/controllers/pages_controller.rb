class PagesController < ApplicationController
    def home
    end

    def login
    end

    def register
        
    end
end
class EstadoPropuestum < ApplicationRecord
end

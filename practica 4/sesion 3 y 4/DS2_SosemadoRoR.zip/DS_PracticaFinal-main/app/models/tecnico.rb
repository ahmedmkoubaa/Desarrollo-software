class Tecnico < ApplicationRecord
end

class TipoTrabajo < ApplicationRecord
end

class Propuestas < ApplicationRecord
end

class Trabajo < ApplicationRecord
end
